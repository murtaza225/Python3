import cv2
import numpy as np
import face_recognition

# Load the known faces and their names
known_faces = []
known_names = []

# Add your known faces and their names to the lists
known_faces.append(face_recognition.load_image_file("known_faces/Akhtar.jpg"))
known_names.append("Akhtar Ali")

# Initialize variables
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True

# Load the video capture
cap = cv2.VideoCapture(0)

# Main program loop
while True:
    # Capture frame-by-frame
    ret, frame = cap.read()

    # Resize the frame to speed up face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # Convert the image from BGR color (OpenCV default) to RGB color (face_recognition library requirement)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    # Process every other frame to improve performance
    if process_this_frame:
        # Find all the faces and their encodings in the current frame
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        # Initialize an empty list for face names
        face_names = []

        # Compare each face encoding with the known face encodings
        for face_encoding in face_encodings:
            # Check if the face matches any known faces
            matches = face_recognition.compare_faces(known_faces, face_encoding)
            name = "Unknown"

            # If there is a match, find the index of the first known face and use the corresponding name
            if True in matches:
                first_match_index = matches.index(True)
                name = known_names[first_match_index]

            # Add the name to the face names list
            face_names.append(name)

    process_this_frame = not process_this_frame

    # Display the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up the face locations since the frame was scaled down
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # Draw a rectangle around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Draw a label with the name below the face
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

    # Display the resulting image
    cv2.imshow('Face Recognition Attendance', frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close all windows
cap.release()
cv2.destroyAllWindows()
